package com.sena.crud_basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
